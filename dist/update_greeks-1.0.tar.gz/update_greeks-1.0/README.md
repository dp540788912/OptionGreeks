# OptionGreeks
## API use:
get_greeks(_date, sc_only=False, implied_forward=False)

## arguments specification: 
_date: exact date, in datetime.datetime format 
sc_only: if True, shows only options whose underlying asset is stock
implied_forward: if True, shows result calculated by the implied method 

